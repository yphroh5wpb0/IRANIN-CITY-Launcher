# IRANIN CITY Launcher

لانچر اندرویدی سرور SA-MP با مشخصات:

- Server: IRANIN CITY
- IP: SvSamp.ir:4444
- Rubika: @IRANIN_CITY

## ساخت APK
پروژه را روی GitHub قرار بده و از بخش Actions، workflow با نام `Build IRANIN CITY APK` را اجرا کن.
فایل APK در Artifacts قرار می‌گیرد.

> توجه: باز کردن مستقیم SA-MP به scheme کلاینت نصب‌شده بستگی دارد. اگر کلاینت scheme متفاوتی داشته باشد، لانچر IP را کپی می‌کند تا بتوانی داخل کلاینت وارد کنی.
