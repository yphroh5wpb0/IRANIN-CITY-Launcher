package ir.iranincity.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val serverIp = "SvSamp.ir:4444"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 32)
            setBackgroundColor(Color.rgb(9, 11, 18))
        }

        val title = TextView(this).apply {
            text = "IRANIN CITY"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "SA-MP • ROLEPLAY\n$serverIp"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 35)
        }

        val play = Button(this).apply {
            text = "ورود به سرور"
            textSize = 18f
            setOnClickListener { launchSamp() }
        }

        val rubika = Button(this).apply {
            text = "کانال روبیکا  @IRANIN_CITY"
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://rubika.ir/IRANIN_CITY")))
                } catch (_: Exception) {}
            }
        }

        val info = TextView(this).apply {
            text = "به شهر IRANIN CITY خوش آمدید 🇮🇷\nنسخه 1.0"
            textSize = 14f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(play, LinearLayout.LayoutParams(-1, 60))
        root.addView(rubika, LinearLayout.LayoutParams(-1, 60))
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun launchSamp() {
        val candidates = listOf(
            "samp://$serverIp",
            "sampmobile://$serverIp",
            "samp://SvSamp.ir:4444"
        )

        for (uriText in candidates) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uriText)))
                return
            } catch (_: ActivityNotFoundException) {
            }
        }

        // Fallback: copy server address so it can be pasted into the SA-MP client.
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("IRANIN CITY", serverIp))
        android.widget.Toast.makeText(this, "آیپی سرور کپی شد: $serverIp", android.widget.Toast.LENGTH_LONG).show()
    }
}
